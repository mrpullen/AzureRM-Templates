**Description**

This resource will allow specifying which SQL Server AlwaysOn Availability group a 
resource should be in. This resource does not configure the Availability Groups on 
SQL Server, they must already exist. It simply adds the specified database to the group.
